define(function(require, exports, module) {
	require("css/reset.css");
	require("modules/bg/bg.js");
	require("modules/bg/bg.css");
	require("modules/header/header");
	require("modules/header/header.css");
	require("modules/portfolio/portfolio");
	require("modules/portfolio/portfolio.css");
})