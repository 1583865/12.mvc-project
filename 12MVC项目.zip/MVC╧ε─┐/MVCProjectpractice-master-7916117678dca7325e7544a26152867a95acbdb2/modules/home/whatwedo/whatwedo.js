define(function(require, exports, module) {
	MVC.addCtrl("whatwedo", function(M, V) {
		
	})
})