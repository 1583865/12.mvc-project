define(function(require, exports, module) {
	MVC.addCtrl("latestworks", function(M, V){
		
	})
})